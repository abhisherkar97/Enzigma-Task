package io.github.mfaisalkhatri.logintestdemo;

import io.github.mfaisalkhatri.logintestdemo.pages.LoginPage;
import io.github.mfaisalkhatri.logintestdemo.pages.MyAccountPage;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class LoginPageTest extends BaseTest {

    @DataProvider
    public Iterator<Object[]> getSignupData() {
        List<Object[]> SignupData = new ArrayList<>();
        SignupData.add(new Object[]{"Abhisherk Sherkar", "abhisheksherkar2001@gmail.com", "Password"," Abhi@9797", false});
        SignupData.add(new Object[]{"Abhisherk Sherkar", "abhisheksherkar2001@gmail.com", "","Abhi@9797" false});
        SignupData.add(new Object[]{"Abhisherk Sherkar", "abhisheksherkar2001@gmail.com", "Abhi@9797","Abhi@9797", true});
        return SignupData.iterator();
    }

    @Test(dataProvider = "getSignupData")
    public void testSignupFeature(String name, String email, String password, String conformpassword, boolean isValidUser) {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.performLogin(name, email, password, conformpassword);

        if (!isValidUser) {
            assertEquals(loginPage.getErrorMessageText(), "Something error in details");
        }
        else {
            assertEquals(loginPage.SuccesfulMessageText(), "Account created successfully!");
        }
    }
    @DataProvider
    public Iterator<Object[]> getLoginData() {
        List<Object[]> loginData = new ArrayList<>();
        loginData.add(new Object[]{"abhisheksherkar2001@gmail.com", "Password", false});
        loginData.add(new Object[]{"abhisheksherkar2001@gmail.com", "", false});
        loginData.add(new Object[]{"abhisheksherkar2001@gmail.com", "Abhi@9797", true});
        return loginData.iterator();
    }

    @Test(dataProvider = "getLoginData")
    public void testLoginFeature(String email, String password, boolean isValidUser) {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.performLogin(email, password);

        if (!isValidUser) {
            assertEquals(loginPage.getErrorMessageText(), "Invalid username and passsword");
        }
        else {
            assertEquals(loginPage.SuccesfulMessageText(), "Succesfully login");
        }
    }
    @DataProvider
    public Iterator<Object[]> getForgotData() {
        List<Object[]> ForgotData = new ArrayList<>();
        forgotData.add(new Object[]{"abhisheksherkar2001@gmail@.com", false});
        forgotdata.add(new Object[]{"", false});
        forgotdata.add(new Object[]{"abhisheksherkar2001@gmail.com",  true});
        return forgotdata.iterator();
    }

    @Test(dataProvider = "getForgotData")
    public void testForgotFeature(String email, boolean isValidUser) {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.performLogin(email);

        if (!isValidUser) {
            assertEquals(loginPage.getErrorMessageText(), "Invalid emial");
        }
        else {
            assertEquals(loginPage.SuccesfulMessageText(), "Reset link sent to your emai");

        }
    }
}